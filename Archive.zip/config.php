<?php
$servername = "146.190.144.31";
$port = 33073;
$dbname = "blog_s013";
$username = "student_s013";
$password = "5bIzdgSzmIV77J#KfMz-";

<?php>